BASE_FILE_LOCATION = "/home/lwl501/website/"
NUMBER_OF_ATTACKS = 2
NUMBER_OF_ROUNDS = 20
NUMBER_OF_WORDS = 5

# Number of initial rounds that can't contain an attack
GRACE_ROUNDS = 5 

# Not zero indexed
ATTENSION_CHECK_ROUND = 3 
