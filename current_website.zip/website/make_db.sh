python3 -c "from server import db; db.create_all()"
