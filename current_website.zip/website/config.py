BASE_FILE_LOCATION = "/home/lwl501/website/"
NUMBER_OF_ATTACKS = 5
NUMBER_OF_ROUNDS = 25
NUMBER_OF_WORDS = 5

# Number of initial rounds that can't contain an attack
GRACE_ROUNDS = 4 
